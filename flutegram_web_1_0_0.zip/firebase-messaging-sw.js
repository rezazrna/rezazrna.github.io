// importScripts('https://www.gstatic.com/firebasejs/9.18.0/firebase-app.js');
// importScripts('https://www.gstatic.com/firebasejs/9.18.0/firebase-analytics.js');

  //  /*Update with yours config*/
  //  const firebaseConfig = {
  //   apiKey: "AIzaSyDsYp8rysZTgPT02WPDvpaJtjr5Yg49k6Y",
  //   authDomain: "flutegram-73df1.firebaseapp.com",
  //   projectId: "flutegram-73df1",
  //   storageBucket: "flutegram-73df1.appspot.com",
  //   messagingSenderId: "277143437892",
  //   appId: "1:277143437892:web:47232b306e29e53f47b211",
  //   measurementId: "G-17S9ZDQRXT"
  // };

  // firebase.initializeApp(firebaseConfig);
  // const messaging = firebase.messaging();

  // /*messaging.onMessage((payload) => {
  // console.log('Message received. ', payload);*/
  // messaging.onBackgroundMessage(function(payload) {
  //   console.log('Received background message ', payload);

  //   const notificationTitle = payload.notification.title;
  //   const notificationOptions = {
  //     body: payload.notification.body,
  //   };

  //   self.registration.showNotification(notificationTitle,
  //     notificationOptions);
  // });